import { useEffect, useState } from "react";
import API from "./services/api";
import Dashboard from "./pages/Dashboard";

function App() {
  const [weather, setWeather] = useState(null);
  const [history, setHistory] = useState(null);
  const [apod, setApod] = useState(null);
  const [lastUpdated, setLastUpdated] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Fetch all APIs together
      const [weatherResponse, historyResponse, apodResponse] =
        await Promise.all([
          API.get("/space-weather"),
          API.get("/kp-history"),
          API.get("/apod"),
        ]);

      console.log("Weather:", weatherResponse.data);
      console.log("History:", historyResponse.data);
      console.log("APOD:", apodResponse.data);

      setWeather(weatherResponse.data);
      setHistory(historyResponse.data);
      setApod(apodResponse.data);

      setLastUpdated(new Date().toLocaleString());
    } catch (error) {
      console.error("API Error:", error);
    }
  };

  return (
    <Dashboard
      weather={weather}
      history={history}
      apod={apod}
      lastUpdated={lastUpdated}
    />
  );
}

export default App;