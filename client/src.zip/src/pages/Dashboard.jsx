import Navbar from "../components/Navbar";
import SpaceWeatherCard from "../components/SpaceWeatherCard";
import RiskCard from "../components/RiskCard";
import RecommendationCard from "../components/RecommendationCard";
import KpChart from "../components/KpChart";
import SatelliteStatus from "../components/SatelliteStatus";
import PredictionCard from "../components/PredictionCard";
import APODCard from "../components/APODCard";
import RefreshButton from "../components/RefreshButton";

import "../style/Dashboard.css";

function Dashboard({ weather, history, apod, lastUpdated }) {
  return (
    <div className="dashboard">
      <Navbar />

      <h1 className="dashboard-title">
        🚀 SpaceGuard AI Dashboard
      </h1>

      <p className="last-updated">
        Last Updated: {lastUpdated}
      </p>

      <div className="card-grid">

        {/* Space Weather */}
        <div className="card">
          <SpaceWeatherCard weather={weather} />
        </div>

        {/* Risk */}
        <div className="card">
          <RiskCard weather={weather} />
        </div>

        {/* Recommendation */}
        <div className="card">
          <RecommendationCard weather={weather} />
        </div>

        {/* KP Chart */}
        <div className="chart-card">
          <KpChart history={history} />
        </div>

        {/* NASA APOD */}
        <div className="card">
          <APODCard apod={apod} />
        </div>

        {/* Satellite Status */}
        <div className="card">
          <SatelliteStatus weather={weather} />
        </div>

        {/* Prediction */}
        <div className="card">
          <PredictionCard weather={weather} />
        </div>

        {/* Refresh Button */}
        <div className="refresh-area">
          <RefreshButton />
        </div>

      </div>
    </div>
  );
}

export default Dashboard;