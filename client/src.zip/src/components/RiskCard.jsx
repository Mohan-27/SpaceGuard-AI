function RiskCard({ weather }) {
  if (!weather) return null;

  return (
    <div
      style={{
        border: "1px solid gray",
        margin: "20px",
        padding: "20px",
        textAlign: "center",
      }}
    >
      <h2>⚠ Risk Level</h2>

      <h3>{weather.risk_level}</h3>

      <h4>
        Risk Score: <span>{weather.risk_score}%</span>
      </h4>
    </div>
  );
}

export default RiskCard;