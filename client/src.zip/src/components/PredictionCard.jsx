function PredictionCard({ weather }) {
  if (!weather) return null;

  const kp = weather.kp_index;

  let prediction = "";
  let color = "";
  let icon = "";

  if (kp < 3) {
    prediction = "Space weather is expected to remain stable for the next 24 hours.";
    color = "#28a745";
    icon = "🟢";
  } else if (kp < 5) {
    prediction = "Minor geomagnetic activity may occur in the next few hours.";
    color = "#ffc107";
    icon = "🟡";
  } else if (kp < 7) {
    prediction = "High probability of communication and GPS disturbances.";
    color = "#fd7e14";
    icon = "🟠";
  } else {
    prediction = "Extreme geomagnetic storm likely. Satellite operations may be affected.";
    color = "#dc3545";
    icon = "🔴";
  }

  return (
    <div
      style={{
        width: "85%",
        margin: "20px auto",
        padding: "20px",
        borderRadius: "10px",
        border: `2px solid ${color}`,
        background: "#fff",
      }}
    >
      <h2 style={{ textAlign: "center" }}>
        🤖 AI Prediction
      </h2>

      <h3
        style={{
          color: color,
          textAlign: "center",
        }}
      >
        {icon} Next 24 Hours
      </h3>

      <p
        style={{
          textAlign: "center",
          fontSize: "18px",
        }}
      >
        {prediction}
      </p>
    </div>
  );
}

export default PredictionCard;