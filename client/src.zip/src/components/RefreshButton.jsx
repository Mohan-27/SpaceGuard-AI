function RefreshButton() {
  return (
    <div style={{ textAlign: "center" }}>
      <button>🔄 Refresh Data</button>
    </div>
  );
}

export default RefreshButton;