function SpaceWeatherCard({ weather }) {
  if (!weather) {
    return <h2>Loading Space Weather...</h2>;
  }

  return (
    <div style={{ border: "1px solid gray", margin: "20px", padding: "20px" }}>
      <h2>🌍 Current Space Weather</h2>

      <p>Solar Activity : {weather.solar_activity}</p>

      <p>KP Index : {weather.kp_index}</p>
    </div>
  );
}

export default SpaceWeatherCard;