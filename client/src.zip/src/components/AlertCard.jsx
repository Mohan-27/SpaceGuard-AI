function AlertCard({ weather }) {
  if (!weather) return null;

  let backgroundColor = "#d4edda";
  let borderColor = "#28a745";
  let alertTitle = "🟢 LOW RISK";
  let message = "No geomagnetic storm detected. Satellite operations are normal.";

  if (weather.kp_index >= 4 && weather.kp_index < 6) {
    backgroundColor = "#fff3cd";
    borderColor = "#ffc107";
    alertTitle = "🟡 MODERATE RISK";
    message = "Minor geomagnetic activity detected. Continue monitoring.";
  }

  if (weather.kp_index >= 6 && weather.kp_index < 8) {
    backgroundColor = "#ffe5b4";
    borderColor = "#fd7e14";
    alertTitle = "🟠 HIGH RISK";
    message =
      "Possible GPS and satellite communication disturbances.";
  }

  if (weather.kp_index >= 8) {
    backgroundColor = "#f8d7da";
    borderColor = "#dc3545";
    alertTitle = "🔴 EXTREME RISK";
    message =
      "Severe geomagnetic storm detected. Satellite operations may be affected.";
  }

  return (
    <div
      style={{
        width: "85%",
        margin: "20px auto",
        padding: "20px",
        borderRadius: "10px",
        backgroundColor: backgroundColor,
        border: `2px solid ${borderColor}`,
        textAlign: "center",
      }}
    >
      <h2>🚨 Space Weather Alert</h2>

      <h3>{alertTitle}</h3>

      <p>
        <strong>KP Index:</strong> {weather.kp_index}
      </p>

      <p>{message}</p>
    </div>
  );
}

export default AlertCard;