function SatelliteStatus({ weather }) {
  if (!weather) {
    return <h2>Loading Satellite Status...</h2>;
  }

  const kp = weather.kp_index;

  const getStatus = () => {
    if (kp <= 3) {
      return {
        text: "🟢 Healthy",
        color: "green",
      };
    }

    if (kp <= 5) {
      return {
        text: "🟡 Warning",
        color: "orange",
      };
    }

    if (kp <= 7) {
      return {
        text: "🟠 Critical",
        color: "darkorange",
      };
    }

    return {
      text: "🔴 Offline",
      color: "red",
    };
  };

  const status = getStatus();

  const satellites = [
    "GPS Satellite",
    "Communication Satellite",
    "Weather Satellite",
    "Navigation Satellite",
  ];

  return (
    <div
      style={{
        width: "85%",
        margin: "30px auto",
        padding: "20px",
        background: "white",
        borderRadius: "10px",
        boxShadow: "0 0 10px rgba(0,0,0,0.15)",
      }}
    >
      <h2 style={{ textAlign: "center" }}>
        🛰 Satellite Health Monitor
      </h2>

      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
        }}
      >
        <thead>
          <tr>
            <th
              style={{
                borderBottom: "2px solid gray",
                padding: "12px",
              }}
            >
              Satellite
            </th>

            <th
              style={{
                borderBottom: "2px solid gray",
                padding: "12px",
              }}
            >
              Status
            </th>
          </tr>
        </thead>

        <tbody>
          {satellites.map((satellite, index) => (
            <tr key={index}>
              <td
                style={{
                  padding: "15px",
                  borderBottom: "1px solid #ddd",
                }}
              >
                {satellite}
              </td>

              <td
                style={{
                  padding: "15px",
                  color: status.color,
                  fontWeight: "bold",
                  borderBottom: "1px solid #ddd",
                }}
              >
                {status.text}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default SatelliteStatus;