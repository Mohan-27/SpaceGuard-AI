function APODCard({ apod }) {
  if (!apod) {
    return (
      <div className="card">
        <h2>🌌 NASA Astronomy Picture of the Day</h2>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>🌌 NASA Astronomy Picture of the Day</h2>

      <h3>{apod.title}</h3>

      {apod.media_type === "image" ? (
        <img
          src={apod.url}
          alt={apod.title}
          style={{
            width: "100%",
            borderRadius: "10px",
            marginTop: "15px",
          }}
        />
      ) : (
        <iframe
          src={apod.url}
          title="NASA APOD"
          width="100%"
          height="500"
        />
      )}

      <p
        style={{
          marginTop: "20px",
          lineHeight: "1.7",
          textAlign: "justify",
        }}
      >
        {apod.explanation}
      </p>
    </div>
  );
}

export default APODCard;