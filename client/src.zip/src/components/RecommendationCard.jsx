function RecommendationCard({ weather }) {
  if (!weather) return null;

  return (
    <div style={{ border: "1px solid gray", margin: "20px", padding: "20px" }}>
      <h2>🤖 AI Recommendation</h2>

      <p>{weather.recommendation}</p>
    </div>
  );
}

export default RecommendationCard;