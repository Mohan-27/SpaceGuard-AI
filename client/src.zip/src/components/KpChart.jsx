import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

import { Line } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function KpChart({ history }) {
  // Print data in browser console
  console.log("History received:", history);

  // If history is not loaded yet
  if (!history) {
    return (
      <h2 style={{ textAlign: "center", marginTop: "30px" }}>
        Loading Chart...
      </h2>
    );
  }

  // Check if labels and values exist
  if (!history.labels || !history.values) {
    return (
      <div style={{ textAlign: "center", marginTop: "30px" }}>
        <h2>❌ Invalid History Data</h2>
        <pre>{JSON.stringify(history, null, 2)}</pre>
      </div>
    );
  }

  const data = {
    labels: history.labels,
    datasets: [
      {
        label: "KP Index",
        data: history.values,
        borderColor: "blue",
        backgroundColor: "rgba(0, 0, 255, 0.2)",
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        display: true,
        position: "top",
      },
      title: {
        display: true,
        text: "Live KP Index History",
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 9,
      },
    },
  };

  return (
    <div
      style={{
        width: "90%",
        margin: "30px auto",
      }}
    >
      <Line data={data} options={options} />
    </div>
  );
}

export default KpChart;