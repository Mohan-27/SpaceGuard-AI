function Navbar() {
  return (
    <nav
      style={{
        background: "#0b3d91",
        color: "white",
        padding: "15px",
        textAlign: "center",
        fontSize: "24px",
      }}
    >
      🚀 SpaceGuard AI
    </nav>
  );
}

export default Navbar;